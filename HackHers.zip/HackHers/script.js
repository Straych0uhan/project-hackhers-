let time = 1500;
let timerRunning = false;
let interval;
ccccc
let sessions = 0;

function updateTimer() {
  let minutes = Math.floor(time / 60);
  let seconds = time % 60;

  seconds = seconds < 10 ? '0' + seconds : seconds;

  document.getElementById('timer').innerText =
    `${minutes}:${seconds}`;

  if (time > 0) {
    time--;
  } else {
    clearInterval(interval);
    alert("Session Completed!");

    sessions++;
    document.getElementById('sessions').innerText = sessions;
  }
}

function startTimer() {
  if (!timerRunning) {
    interval = setInterval(updateTimer, 1000);
    timerRunning = true;
  }
}

function resetTimer() {
  clearInterval(interval);
  time = 1500;
  timerRunning = false;
  document.getElementById('timer').innerText = "25:00";
}

function saveGoal() {
  let goal = document.getElementById('goalInput').value;

  document.getElementById('goalText').innerText =
    "Your Goal: " + goal;
}

function saveNotes() {
  let notes = document.getElementById('notesInput').value;

  localStorage.setItem("studyNotes", notes);

  alert("Notes Saved!");
}

window.onload = function() {
  let savedNotes = localStorage.getItem("studyNotes");

  if(savedNotes) {
    document.getElementById('notesInput').value = savedNotes;
  }
}